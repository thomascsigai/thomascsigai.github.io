try:
#On essaie d'importer Pygame
    import pygame
    from pygame.locals import *
    from pygame.font import Font
    #On commence par importer le module Pygame ainsi que ses variables (MOUSEBUTTONDOWN ...) et ses polices
except ImportError:
    print("Pygame doit être installé")
    #Si Pygame n'est pas intallé, le programme affiche le message précèdent

pygame.init()
#On initialise pygame

fenetre = pygame.display.set_mode((800, 600))
#On définit une fenêtre de 800 par 600 pixels qui sera considéré comme une surface
fond = pygame.image.load('bg.jpg')
#On importe l'image de fond du jeu qui fait 800 par 600 pixels ...
fenetre.blit(fond,(0,0))
#... Et on l'affiche sur la surface fenêtre
clock=pygame.time.Clock()
#On crée un objet clock pour gérer le nombre d'image par seconde du jeu
allpieces = pygame.sprite.Group()
#On crée une varible allpieces qui correspond à toutes les images (sprites) contenues dans une classe
font_titres = pygame.font.SysFont('arial', 55)
font_soustitres = pygame.font.SysFont('arial', 40)
#On définit 2 police et leur taille qui seront utilisées pour les titres

titrep4 = font_titres.render("Puissance 4",1,(255,255,0))
stitre_nbj = font_soustitres.render("Choisissez le nombre de joueurs",1,(255,255,0))
stitre_nomj = font_soustitres.render("Entrez les noms des joueurs",1,(255,255,0))
stitre_nomj1 = font_soustitres.render("Joueur 1 :",1,(255,255,0))
stitre_nomj2 = font_soustitres.render("Joueur 2 :",1,(255,255,0))
#Ici on définit les titres affichés à l'écran en leur assignant une des deux polices définies précèdemment et on les stockes dans titrep4, stitre_nbj etc par exemple

fps = 60
#fps correspond au nombre d'images par seconde du jeu

class Boutton(pygame.sprite.Sprite):
#On crée la classe bouton qui permettra de créer et gérer les boutons
    def __init__ (self,x,y,index,visible):
    #x,y,index,visible correspondent aux variables à entrer pour créer le bouton.
    #Ici la position en x, y, index qui correspond à son identifiant et visible son image
    #On initialise les variables des boutons
        pygame.sprite.Sprite.__init__(self)
        #self. permet de définir la variable de tous les boutons et pas d'un seul
        self.visible = visible
        self.image = self.visible #Ici l'image du bouton correspond au visible du bouton
        # qui sera entré pendant la création du bouton
        self.rect = self.image.get_rect() #On prend le point de collision de l'image du bouton
        #qui permettre de vérifier des collisions avec d'autres objets comme le curseur de la souris
        self.rect.x = x #Position en x du bouton
        self.rect.y = y #Position en y du bouton
        self.index = index #Index du bouton, son identifiant
        self.add(allpieces) #On ajoute tous le bouton dans l'objet allpieces
        self.set = pygame.sprite.RenderPlain((self))


    def update(self):
    #Avec la fontion update, on va pouvoir vérifier des conditions
        global continuer
        global suite
        global suite1
        global suite_1j
        if self.index == 1 and event.type == MOUSEBUTTONDOWN and event.pos[0] > self.rect.x and event.pos[0] < self.rect.x + 200 and event.pos[1] > self.rect.y and event.pos[1] < self.rect.y + 60:
        #Ici , si l'utilisateur clique sur un bouton, si c'est le bouton 1 (le bouton jouer) alors suite = True
            suite = True #Le jeu continue
        if self.index == 2 and event.type == MOUSEBUTTONDOWN and event.pos[0] > self.rect.x and event.pos[0] < self.rect.x + 200 and event.pos[1] > self.rect.y and event.pos[1] < self.rect.y + 60:
        #Ici , si l'utilisateur clique sur un bouton, si c'est le bouton 2 (le bouton quitter) alors continuer = False
            continuer = False #Le jeu s'arrête
        if self.index == 3 and event.type == MOUSEBUTTONDOWN and event.pos[0] > self.rect.x and event.pos[0] < self.rect.x + 200 and event.pos[1] > self.rect.y and event.pos[1] < self.rect.y + 60:
        #Ici , si l'utilisateur clique sur un bouton, si c'est le bouton 3 (le bouton 1 joueur) alors suite_1j = True
            suite_1j = True #Le jeu continue pour un joueur
        elif self.index == 4 and event.type == MOUSEBUTTONDOWN and event.pos[0] > self.rect.x and event.pos[0] < self.rect.x + 200 and event.pos[1] > self.rect.y and event.pos[1] < self.rect.y + 60:
        #Ici , si l'utilisateur clique sur un bouton, si c'est le bouton 4 (le bouton 2 joueurs) alors suite1 = True
            suite1 = True #Le jeu continue pour deux joueurs

boutton_jouer = Boutton(100,100,1,pygame.image.load("boutton_jouer.png").convert_alpha())
#On crée le boutton jouer en entrant sa position en x, en y, son identifiant 1 et on charge son image
boutton_quitter = Boutton(500,100,2,pygame.image.load("boutton_quitter.png").convert_alpha())
#On crée le bouton quitter en entrant sa position en x, en y, son identifiant 2 et on charge son image

class Name():
#On crée la classe Name qui permet de créer et gérer les zones de saisie de texte
    def name():
    #La fonction name correspond à la zone de saisie de texte du joueur 1 si la partie est en mode 2 joueurs
        global nom1
        global suite2
        name = "" #On crée une varible (texte) name qui sera vide
        font = pygame.font.SysFont('arial', 40) #On définit une police pour l'affichage du nom
        while True:
        #On crée une boucle pour vérifier les conditions
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                #Si une touche est enfoncée
                    if event.unicode.isalpha():
                    #Si la touche enfoncée est une lettre (Majuscule ou minuscule) du clavier alors ...
                        name += event.unicode #... On ajoute à la varible name cette lettre
                    elif event.key == K_BACKSPACE:
                    #Si la touche enfoncée est le bouton BackSpace permettant d'effecer une lettre ...
                        name = name[:-1] #...On enlève la dernière lettre de la variable name
                    elif event.key == K_RETURN:
                    #Si la touche enfoncée est la touche entrée ...
                        name = "" #...On termine la variable name
                        print("Nom du premier joueur =",nom1) #On affiche la varibale du nom
                        suite2 = True #On continue le jeu
                        return #On quitte le jeu
                    elif event.key == QUIT:
                    #Si l'utilisateur clique sur le bouton quitter ...
                        pygame.quit() #... On quitte le jeu
                    block = font.render(name, True, (255, 255, 255)) #On crée un block qui affichera le texte entré par l'utilisateur
                    fenetre.blit(block, (160,426)) #On affiche le block en 160 et 426
                    pygame.display.flip() #On rafraichit l'écran
                    nom1 = name #On stocke la variable name dans nom1 qui est une variable globale, commune à tout le code

    def name1():
    #La fonction name correspond à la zone de saisie de texte du joueur 2 si la partie est en mode 2 joueurs
        global nom2
        name = ""
        font = pygame.font.SysFont('arial', 40)
        while True:
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.unicode.isalpha():
                        name += event.unicode
                    elif event.key == K_BACKSPACE:
                        name = name[:-1]
                    elif event.key == K_RETURN:
                        name = ""
                        print("Nom du deuxième joueur =",nom2)
                        import launch_puissance4 #On import le code du jeu et on le lance
                    elif event.key == QUIT:
                        pygame.quit()
                    block = font.render(name, True, (255, 255, 255))
                    fenetre.blit(block, (160,506))
                    pygame.display.flip()
                    nom2 = name

    def name2():
    #La fonction name correspond à la zone de saisie de texte du joueur 1 si la partie est en mode 1 joueur
        global nom1
        global suite2
        name = ""
        font = pygame.font.SysFont('arial', 40)
        while True:
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.unicode.isalpha():
                        name += event.unicode
                    elif event.key == K_BACKSPACE:
                        name = name[:-1]
                    elif event.key == K_RETURN:
                        name = ""
                        print("Nom du premier joueur =",nom1)
                        fenetre.blit(fond,(0,0))
                        pygame.display.flip()
                        pygame.quit()
                    elif event.key == QUIT:
                        pygame.quit()
                    block = font.render(name, True, (255, 255, 255))
                    fenetre.blit(block, (160,426))
                    pygame.display.flip()
                    nom1 = name

continuer = True
suite = False
suite1 = False
suite2 = False
suite3 = False
suite_1j = False
while continuer:
#On crée un boucle infinie pour vérifier des conditons
    fenetre.blit(titrep4,(300,35))
    pygame.display.flip()
    #On affiche le titre du jeu
    for event in pygame.event.get():
        if event.type == QUIT:
        #Si l'utilisateur appuie sur la flèche pour quitter la fenêtre ...
            continuer = False #...La variale continuer = False ce qui quitte la boucle infinie et ferme la fenêtre
    if suite:
    #Variable appellée après avoir cliqué sur le bouton jouer
        fenetre.blit(stitre_nbj,(180,198))
        pygame.display.flip()
        #On Affiche les titres
        boutton_1joueur = Boutton(100,260,3,pygame.image.load("boutton_1j.png").convert_alpha())
        boutton_2joueur = Boutton(500,260,4,pygame.image.load("boutton_2j.png").convert_alpha())
        #On crée les deux nouveaux boutons pour choisir le nombre de joueurs
    if suite1:
    #Varible appellée après avoir cliqué sur le bouton 2 joueurs
        fenetre.blit(stitre_nomj,(200,360))
        fenetre.blit(stitre_nomj1,(10,426))
        pygame.display.flip()
        #On affiche les titres
        name1 = Name.name()
        #Et on crée la zone de saisie de texte du joueur 1
    if suite2:
    #Varible appellée après avoir entré le premier nom
        fenetre.blit(stitre_nomj2,(10,506))
        pygame.display.flip()
        #On affiche le titre
        name2 = Name.name1()
        #Et on crée la zone de saisie de texte du joueur 2
    if suite_1j:
    #Variable appellée après avoir cliqué sur le bouton 1 joueur
        fenetre.blit(stitre_nomj,(200,360))
        fenetre.blit(stitre_nomj1,(10,426))
        pygame.display.flip()
        #On affcihe les titres
        name3 = Name.name2()
        #Et on crée la zone de saisie de texte du joueur 1
    allpieces.update()
    #On met à jour les sprites des pièces qu'on a intégré dans allpieces
    allpieces.draw(fenetre)
    #Et on les affiche à l'écran
    clock.tick(fps)
    #On définit le nombre d'images par secondes du jeu avec la variable fps qui est de 60
